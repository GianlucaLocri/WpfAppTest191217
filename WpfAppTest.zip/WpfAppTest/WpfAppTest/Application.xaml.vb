﻿Imports Prism.Ioc
Imports Prism.Unity

Class App
    Inherits PrismApplication

    Protected Overrides Sub RegisterTypes(containerRegistry As IContainerRegistry)
    End Sub

    Protected Overrides Function CreateShell() As Window
        Return Container.Resolve(Of MainWindow)
    End Function

End Class